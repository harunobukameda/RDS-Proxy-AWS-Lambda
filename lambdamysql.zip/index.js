var mysql = require('mysql');


exports.handler = function(event,context){

    var connection = mysql.createConnection({
      host     : 'database-1-instance-1.cezfqx1ilrp8.ap-northeast-1.rds.amazonaws.com', //RDSのエンドポイント
      user     : 'admin', //MySQLのユーザ名
      password : 'password', //MySQLのパスワード
      database : 'test'
    });

    connection.connect();

    connection.query('select * from sample', function(err, rows, fields) {
      if (err) throw err;

      console.log(rows);
      console.log(fields);
    });

    connection.end(function(err) {
        context.done();
    });

}