ql = require('mysql');


exports.handler = function(event,context){

	    var connection = mysql.createConnection({
		          host     : 'mysql -u admin -h database-1-instance-1.cezfqx1ilrp8.ap-northeast-1.rds.amazonaws.com -p', //RDS
		          user     : 'admin', //MySQL
		          password : 'password', //MySQ
		          database : 'test'
		        });

	    connection.connect();

	    connection.query('select * from sample', function(err, rows, fields) {
		          if (err) throw err;

		          console.log(rows);
		          console.log(fields);
		        });

	    connection.end(function(err) {
		            context.done();
		        });

}
